
			<!-- Main Footer -->
			<footer class="main-footer ">
				<div class="bg-image" style="background-image: url(https://ik.imagekit.io/kgrarhxkv/5.jpg)"></div>
				<div class="anim-icons">
					<span class="icon icon-plane-3 bounce-x"></span>
				</div>

				<!-- Contact info -->
				<div class="contacts-outer p-2">
					<div class="auto-container">
						<div class="row">
							<!-- Contact Info Block -->

							<!-- <div class="contact-info-block col-lg-3 col-md-6 col-sm-12 wow fadeInRight my-auto">
								<div class=" " >
									<a href=""><img src="https://ik.imagekit.io/kgrarhxkv/MM-Logo.jpg"  alt=""></a>
								</div>
							</div> -->


							<div class="contact-info-block col-lg-4 col-md-6 col-sm-12 wow fadeInRight pt-2">
								<div class=" footer-widget">
									<!-- <div class="icon-box"><i class="icon flaticon-international-shipping-2"></i></div> -->
									<h4 class="widget-title">ABOUT</h4>
									<div class="text" style="text-align:justify;">We are providing Manpower with various categories from Semi-skilled workers, skilled Workers, Technicians, Foreman, Engineers, Inspectors, Specialist, Consultant, etc. As such, we are able to secure human resources with the required skills swiftly when necessary.</div>
								</div>
							</div>

                            <div class="contact-info-block col-lg-4 col-md-6 col-sm-12 wow fadeInRight">
								<div class="footer-widget">
									
									<h4 class="widget-title">SERVICES</h4>
									
											<ul class="user-links">
										<li><a href="services.php"><i class=" fa fa-angle-right"></i> Manpower Supply</a></li>
										<li><a href="services.php"><i class=" fa fa-angle-right"></i> Technical  Services</a></li>
										<li><a href="services.php"><i class=" fa fa-angle-right"></i> Material & Equipment Supply</a></li>
										<li><a href="services.php"><i class=" fa fa-angle-right"></i> Recruitment/Headhunt</a></li>
										
									</ul>
											
											
								</div>
							</div>
							
							
							<!-- Contact Info Block -->
							<div class="contact-info-block col-lg-4 col-md-6 col-sm-12 wow fadeInRight" data-wow-delay="300ms" >
								<div class=" footer-widget" style="border-right: none;">
									<!-- <div class="icon-box"><i class="icon flaticon-stock-1"></i></div> -->
									<h4 class="widget-title">CONTACT</h4>
									<div class="text">
									<li><i class="fa fa-envelope"></i> &nbsp admin@mmmanpowerservices.com </li>
							<li><i class="fa fa-phone-volume"></i> &nbsp  +91 9112881228</li>
							<li><i class="fa fa-map"></i> &nbsp Mane & mutake manpower service pvt ltd , near spm English medium school, road mutakewadi-medankarwadi, chakan.</li>
									</div>
								</div>
							</div>

							
						</div>
					</div>
				</div>
				<!-- End Contact info -->

				

				<!--Footer Bottom-->
				<div class="footer-bottom">
					<div class="auto-container">
						<div class="inner-container">
							<div class="copyright-text">
								<p>&copy; Copyright 2024 by <a href="https://pnminfotech.com/">PNM Infotech</a></p>
							</div>

							<!-- <ul class="social-icon-two">
								<li>
									<a href="#"><i class="fab fa-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="fab fa-twitter"></i></a>
								</li>
								<li>
									<a href="#"><i class="fab fa-pinterest"></i></a>
								</li>
								<li>
									<a href="#"><i class="fab fa-instagram"></i></a>
								</li>
							</ul> -->
						</div>
					</div>
				</div>
			</footer>
			<!--End Main Footer -->